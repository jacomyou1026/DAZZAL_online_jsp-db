package com.myhome.dto;

public class BoardDto {

}
